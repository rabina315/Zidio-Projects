import React from 'react';
import { Link } from 'react-router-dom';

export default function PostList({ posts }) {
  if (!posts.length) return <p>No posts found.</p>;

  return (
    <div className="space-y-6">
      {posts.map((post) => (
        <div key={post._id} className="border p-4 rounded shadow hover:shadow-lg transition">
          <Link to={`/posts/${post._id}`}>
            <h2 className="text-xl font-semibold">{post.title}</h2>
          </Link>
          <p className="text-sm text-gray-600">
            Category: {post.category} | By {post.author.username} | {new Date(post.createdAt).toLocaleDateString()}
          </p>
          <div
            className="mt-2 text-gray-800 line-clamp-3"
            dangerouslySetInnerHTML={{ __html: post.content }}
          />
          <p className="mt-2 font-semibold">Likes: {post.likes?.length || 0}</p>
        </div>
      ))}
    </div>
  );
}