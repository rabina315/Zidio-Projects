import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { fetchCommentsByPost, addComment, deleteComment } from '../features/comments/commentsSlice';

export default function CommentSection({ postId }) {
  const dispatch = useDispatch();
  const { comments, status } = useSelector((state) => state.comments);
  const user = useSelector((state) => state.auth.user);
  const [content, setContent] = useState('');

  useEffect(() => {
    dispatch(fetchCommentsByPost(postId));
  }, [dispatch, postId]);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!content.trim()) return;
    dispatch(addComment({ postId, content }));
    setContent('');
  };

  const handleDelete = (id) => {
    dispatch(deleteComment(id));
  };

  return (
    <div className="mt-8">
      <h3 className="text-xl font-semibold mb-2">Comments</h3>
      {user ? (
        <form onSubmit={handleSubmit} className="mb-4">
          <textarea
            className="w-full p-2 border rounded"
            rows="3"
            placeholder="Add a comment..."
            value={content}
            onChange={(e) => setContent(e.target.value)}
            required
          ></textarea>
          <button type="submit" className="mt-2 px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700">
            Comment
          </button>
        </form>
      ) : (
        <p>Please login to add comments.</p>
      )}
      {status === 'loading' && <p>Loading comments...</p>}
      {comments.length === 0 && <p>No comments yet.</p>}
      <ul>
        {comments.map((c) => (
          <li key={c._id} className="border-b py-2">
            <p>
              <strong>{c.author.username}</strong> <span className="text-gray-500 text-sm">{new Date(c.createdAt).toLocaleString()}</span>
            </p>
            <p>{c.content}</p>
            {user && (user.id === c.author._id || user.role === 'admin') && (
              <button
                onClick={() => handleDelete(c._id)}
                className="text-red-600 hover:underline text-sm mt-1"
              >
                Delete
              </button>
            )}
          </li>
        ))}
      </ul>
    </div>
  );
}