import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { fetchPostById, toggleLikePost } from '../features/posts/postsSlice';
import CommentSection from './CommentSection';
import { useParams } from 'react-router-dom';

export default function PostDetail() {
  const { id } = useParams();
  const dispatch = useDispatch();
  const { currentPost, status } = useSelector((state) => state.posts);
  const user = useSelector((state) => state.auth.user);

  useEffect(() => {
    dispatch(fetchPostById(id));
  }, [dispatch, id]);

  if (status === 'loading') return <p>Loading post...</p>;
  if (!currentPost) return <p>Post not found.</p>;

  const liked = currentPost.likes.some((like) => like === user?.id);

  const handleLike = () => {
    if (!user) {
      alert('Please login to like posts');
      return;
    }
    dispatch(toggleLikePost(currentPost._id));
  };

  return (
    <div className="max-w-3xl mx-auto space-y-4">
      <h1 className="text-3xl font-bold">{currentPost.title}</h1>
      <p className="text-sm text-gray-600">
        Category: {currentPost.category} | By {currentPost.author.username} |{' '}
        {new Date(currentPost.createdAt).toLocaleDateString()}
      </p>
      <img src={currentPost.imageUrl} alt={currentPost.title} className="max-h-96 w-full object-cover rounded" />
      <div dangerouslySetInnerHTML={{ __html: currentPost.content }} />
      <button
        onClick={handleLike}
        className={`px-4 py-2 rounded ${liked ? 'bg-red-600 text-white' : 'bg-gray-300'}`}
      >
        {liked ? 'Unlike' : 'Like'} ({currentPost.likes.length})
      </button>
      <CommentSection postId={currentPost._id} />
    </div>
  );
}