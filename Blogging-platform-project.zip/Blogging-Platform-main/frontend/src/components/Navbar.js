import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useSelector, useDispatch } from 'react-redux';
import { logout } from '../features/auth/authSlice';

export default function Navbar() {
  const user = useSelector((state) => state.auth.user);
  const dispatch = useDispatch();
  const navigate = useNavigate();

  const handleLogout = () => {
    dispatch(logout());
    navigate('/');
  };

  return (
    <nav className="bg-gray-800 p-4 text-white flex justify-between">
      <div>
        <Link to="/posts" className="mr-4 font-bold text-xl">
          MERN Blog
        </Link>
        <Link to="/posts" className="mr-2 hover:underline">
          Posts
        </Link>
        {user && (
          <Link to="/create" className="mr-2 hover:underline">
            Create Post
          </Link>
        )}
      </div>
      <div>
        {user ? (
          <>
            <Link to="/profile" className="mr-4 hover:underline">
              {user.username}
            </Link>
            <button onClick={handleLogout} className="hover:underline">
              Logout
            </button>
          </>
        ) : (
          <>
            <Link to="/login" className="mr-4 hover:underline">
              Login
            </Link>
            <Link to="/register" className="hover:underline">
              Register
            </Link>
          </>
        )}
      </div>
    </nav>
  );
}