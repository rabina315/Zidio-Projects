import React, { useState } from 'react';
import ReactQuill from 'react-quill';
import 'react-quill/dist/quill.snow.css';
import axios from 'axios';

export default function PostForm({ initialValues = {}, onSubmit }) {
  const [title, setTitle] = useState(initialValues.title || '');
  const [content, setContent] = useState(initialValues.content || '');
  const [category, setCategory] = useState(initialValues.category || 'General');
  const [imageUrl, setImageUrl] = useState(initialValues.imageUrl || '');
  const [uploading, setUploading] = useState(false);

  const handleImageChange = async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    setUploading(true);
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onloadend = async () => {
      try {
        const res = await axios.post(
          '/api/upload',
          { data: reader.result },
          { headers: { Authorization: `Bearer ${localStorage.getItem('token')}` } }
        );
        setImageUrl(res.data.url);
      } catch (error) {
        alert('Image upload failed');
      } finally {
        setUploading(false);
      }
    };
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!title || !content || !category || !imageUrl) {
      alert('Please fill all fields and upload an image');
      return;
    }
    onSubmit({ title, content, category, imageUrl });
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4 max-w-3xl mx-auto">
      <input
        type="text"
        placeholder="Title"
        className="w-full p-2 border rounded"
        value={title}
        onChange={(e) => setTitle(e.target.value)}
        required
      />
      <select
        value={category}
        className="w-full p-2 border rounded"
        onChange={(e) => setCategory(e.target.value)}
        required
      >
        <option value="General">General</option>
        <option value="Technology">Technology</option>
        <option value="Lifestyle">Lifestyle</option>
        <option value="Education">Education</option>
        <option value="Health">Health</option>
      </select>
      <ReactQuill theme="snow" value={content} onChange={setContent} />
      <div>
        <label className="block mb-1">Upload Image</label>
        <input type="file" accept="image/*" onChange={handleImageChange} />
        {uploading && <p>Uploading image...</p>}
        {imageUrl && <img src={imageUrl} alt="Uploaded" className="mt-2 max-h-48" />}
      </div>
      <button type="submit" className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">
        Submit
      </button>
    </form>
  );
}