import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import axios from 'axios';

const API_URL = '/api/comments';

const initialState = {
  comments: [],
  status: 'idle',
  error: null,
};

export const fetchCommentsByPost = createAsyncThunk('comments/fetchCommentsByPost', async (postId, { rejectWithValue }) => {
  try {
    const res = await axios.get(`${API_URL}/post/${postId}`);
    return res.data;
  } catch (err) {
    return rejectWithValue(err.response?.data?.message || err.message);
  }
});

export const addComment = createAsyncThunk('comments/addComment', async ({ postId, content }, { getState, rejectWithValue }) => {
  try {
    const token = getState().auth.token;
    const res = await axios.post(
      `${API_URL}/${postId}`,
      { content },
      { headers: { Authorization: `Bearer ${token}` } }
    );
    return res.data;
  } catch (err) {
    return rejectWithValue(err.response?.data?.message || err.message);
  }
});

export const deleteComment = createAsyncThunk('comments/deleteComment', async (id, { getState, rejectWithValue }) => {
  try {
    const token = getState().auth.token;
    await axios.delete(`${API_URL}/${id}`, {
      headers: { Authorization: `Bearer ${token}` },
    });
    return id;
  } catch (err) {
    return rejectWithValue(err.response?.data?.message || err.message);
  }
});

const commentsSlice = createSlice({
  name: 'comments',
  initialState,
  reducers: {
    clearComments(state) {
      state.comments = [];
    },
  },
  extraReducers(builder) {
    builder
      .addCase(fetchCommentsByPost.pending, (state) => {
        state.status = 'loading';
      })
      .addCase(fetchCommentsByPost.fulfilled, (state, action) => {
        state.status = 'succeeded';
        state.comments = action.payload;
      })
      .addCase(fetchCommentsByPost.rejected, (state, action) => {
        state.status = 'failed';
        state.error = action.payload;
      })
      .addCase(addComment.fulfilled, (state, action) => {
        state.comments.unshift(action.payload);
      })
      .addCase(deleteComment.fulfilled, (state, action) => {
        state.comments = state.comments.filter((c) => c._id !== action.payload);
      });
  },
});

export const { clearComments } = commentsSlice.actions;

export default commentsSlice.reducer;