import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import axios from 'axios';

const API_URL = '/api/posts';

const initialState = {
  posts: [],
  currentPost: null,
  status: 'idle',
  error: null,
};

export const fetchPosts = createAsyncThunk('posts/fetchPosts', async (params, { rejectWithValue }) => {
  try {
    const query = new URLSearchParams(params).toString();
    const res = await axios.get(`${API_URL}?${query}`);
    return res.data;
  } catch (err) {
    return rejectWithValue(err.response?.data?.message || err.message);
  }
});

export const fetchPostById = createAsyncThunk('posts/fetchPostById', async (id, { rejectWithValue }) => {
  try {
    const res = await axios.get(`${API_URL}/${id}`);
    return res.data;
  } catch (err) {
    return rejectWithValue(err.response?.data?.message || err.message);
  }
});

export const createPost = createAsyncThunk('posts/createPost', async (postData, { getState, rejectWithValue }) => {
  try {
    const token = getState().auth.token;
    const res = await axios.post(API_URL, postData, {
      headers: { Authorization: `Bearer ${token}` },
    });
    return res.data;
  } catch (err) {
    return rejectWithValue(err.response?.data?.message || err.message);
  }
});

export const updatePost = createAsyncThunk('posts/updatePost', async ({ id, postData }, { getState, rejectWithValue }) => {
  try {
    const token = getState().auth.token;
    const res = await axios.put(`${API_URL}/${id}`, postData, {
      headers: { Authorization: `Bearer ${token}` },
    });
    return res.data;
  } catch (err) {
    return rejectWithValue(err.response?.data?.message || err.message);
  }
});

export const deletePost = createAsyncThunk('posts/deletePost', async (id, { getState, rejectWithValue }) => {
  try {
    const token = getState().auth.token;
    await axios.delete(`${API_URL}/${id}`, {
      headers: { Authorization: `Bearer ${token}` },
    });
    return id;
  } catch (err) {
    return rejectWithValue(err.response?.data?.message || err.message);
  }
});

export const toggleLikePost = createAsyncThunk('posts/toggleLikePost', async (id, { getState, rejectWithValue }) => {
  try {
    const token = getState().auth.token;
    const res = await axios.post(`${API_URL}/${id}/like`, null, {
      headers: { Authorization: `Bearer ${token}` },
    });
    return { id, likesCount: res.data.likesCount };
  } catch (err) {
    return rejectWithValue(err.response?.data?.message || err.message);
  }
});

const postsSlice = createSlice({
  name: 'posts',
  initialState,
  reducers: {
    clearCurrentPost(state) {
      state.currentPost = null;
    },
  },
  extraReducers(builder) {
    builder
      .addCase(fetchPosts.pending, (state) => {
        state.status = 'loading';
      })
      .addCase(fetchPosts.fulfilled, (state, action) => {
        state.status = 'succeeded';
        state.posts = action.payload;
      })
      .addCase(fetchPosts.rejected, (state, action) => {
        state.status = 'failed';
        state.error = action.payload;
      })
      .addCase(fetchPostById.pending, (state) => {
        state.status = 'loading';
      })
      .addCase(fetchPostById.fulfilled, (state, action) => {
        state.status = 'succeeded';
        state.currentPost = action.payload;
      })
      .addCase(fetchPostById.rejected, (state, action) => {
        state.status = 'failed';
        state.error = action.payload;
      })
      .addCase(createPost.fulfilled, (state, action) => {
        state.posts.unshift(action.payload);
      })
      .addCase(updatePost.fulfilled, (state, action) => {
        const index = state.posts.findIndex((p) => p._id === action.payload._id);
        if (index !== -1) state.posts[index] = action.payload;
        if (state.currentPost?._id === action.payload._id) state.currentPost = action.payload;
      })
      .addCase(deletePost.fulfilled, (state, action) => {
        state.posts = state.posts.filter((p) => p._id !== action.payload);
        if (state.currentPost?._id === action.payload) state.currentPost = null;
      })
      .addCase(toggleLikePost.fulfilled, (state, action) => {
        const { id, likesCount } = action.payload;
        const post = state.posts.find((p) => p._id === id);
        if (post) post.likesCount = likesCount;
        if (state.currentPost?._id === id) state.currentPost.likesCount = likesCount;
      });
  },
});

export const { clearCurrentPost } = postsSlice.actions;

export default postsSlice.reducer;