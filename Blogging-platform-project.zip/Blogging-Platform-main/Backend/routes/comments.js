import express from 'express';
import { body, validationResult } from 'express-validator';
import Comment from '../models/Comment.js';
import { verifyToken } from '../middleware/authMiddleware.js';

const router = express.Router();

// GET /api/comments/post/:postId
router.get('/post/:postId', async (req, res) => {
  try {
    const comments = await Comment.find({ post: req.params.postId })
      .populate('author', 'username')
      .sort({ createdAt: -1 });
    res.json(comments);
  } catch (error) {
    res.status(500).json({ message: 'Failed to get comments' });
  }
});

// POST /api/comments/:postId
router.post(
  '/:postId',
  verifyToken,
  body('content').isLength({ min: 1 }),
  async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });

    try {
      const comment = new Comment({
        post: req.params.postId,
        author: req.user.id,
        content: req.body.content,
      });
      await comment.save();
      res.status(201).json(comment);
    } catch (error) {
      res.status(500).json({ message: 'Failed to add comment' });
    }
  }
);

// PUT /api/comments/:id
router.put(
  '/:id',
  verifyToken,
  body('content').isLength({ min: 1 }),
  async (req, res) => {
    try {
      const comment = await Comment.findById(req.params.id);
      if (!comment) return res.status(404).json({ message: 'Comment not found' });

      if (comment.author.toString() !== req.user.id && req.user.role !== 'admin') {
        return res.status(403).json({ message: 'Unauthorized' });
      }

      comment.content = req.body.content;
      await comment.save();
      res.json(comment);
    } catch (error) {
      res.status(500).json({ message: 'Failed to update comment' });
    }
  }
);

// DELETE /api/comments/:id
router.delete('/:id', verifyToken, async (req, res) => {
  try {
    const comment = await Comment.findById(req.params.id);
    if (!comment) return res.status(404).json({ message: 'Comment not found' });

    if (comment.author.toString() !== req.user.id && req.user.role !== 'admin') {
      return res.status(403).json({ message: 'Unauthorized' });
    }

    await comment.remove();
    res.json({ message: 'Comment deleted' });
  } catch (error) {
    res.status(500).json({ message: 'Failed to delete comment' });
  }
});

export default router;