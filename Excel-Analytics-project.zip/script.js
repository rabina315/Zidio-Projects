let cartItems = JSON.parse(localStorage.getItem('cartItems')) || [];

function saveCart() {
  localStorage.setItem('cartItems', JSON.stringify(cartItems));
}

function closeProductView() {
  document.getElementById('productOverlay').classList.add('d-none');
  document.body.classList.remove('no-scroll');
  document.querySelectorAll('section, .carousel-wrapper, .buying-section').forEach(el => el.style.display = '');
}

function closeBrandOverlay() {
  document.getElementById('brandOverlay').classList.add('d-none');
  document.body.classList.remove('no-scroll');
  document.querySelectorAll('section, .carousel-wrapper, .buying-section').forEach(el => el.style.display = '');
}

function toggleCartSidebar() {
  const cartSidebar = document.getElementById('cartSidebar');
  cartSidebar.classList.toggle('d-none');
  renderCartItems();
}

function renderCartItems() {
  const cartList = document.getElementById('cartItems');
  const cartTotal = document.getElementById('cartTotal');
  cartList.innerHTML = '';
  let total = 0;

  if (cartItems.length === 0) {
    cartList.innerHTML = '<p class="text-center">Your cart is empty</p>';
    if (cartTotal) cartTotal.innerText = '₹0';
    return;
  }

  cartItems.forEach((item, index) => {
    const price = parseInt(item.price.replace(/[^\d]/g, '')) * (item.qty || 1);
    total += price;

    const div = document.createElement('div');
    div.className = 'cart-item mb-3';
    div.innerHTML = `
      <div class="d-flex justify-content-between align-items-center">
        <div class="d-flex align-items-center">
          <img src="${item.img}" alt="${item.title}" style="width: 60px; height: 60px; object-fit: cover; border-radius: 6px; margin-right: 10px;">
          <div>
            <p class="mb-0 fw-bold">${item.title}</p>
            <p class="mb-0 text-muted small">${item.price}</p>
            <div class="d-flex align-items-center mt-1">
              <button class="btn btn-sm btn-outline-secondary me-1" onclick="updateQty(${index}, -1)">-</button>
              <span>${item.qty || 1}</span>
              <button class="btn btn-sm btn-outline-secondary ms-1" onclick="updateQty(${index}, 1)">+</button>
            </div>
          </div>
        </div>
        <button class="btn btn-sm btn-danger" onclick="removeCartItem(${index})">×</button>
      </div>
    `;
    cartList.appendChild(div);
  });

  if (cartTotal) cartTotal.innerText = `₹${total.toLocaleString()}`;
}

function updateQty(index, change) {
  cartItems[index].qty = (cartItems[index].qty || 1) + change;
  if (cartItems[index].qty < 1) cartItems[index].qty = 1;
  saveCart();
  renderCartItems();
}

function removeCartItem(index) {
  cartItems.splice(index, 1);
  saveCart();
  renderCartItems();
  showToast('Item removed from cart.', 'danger');
}

function clearCart() {
  cartItems = [];
  saveCart();
  renderCartItems();
  showToast('Cart cleared.', 'warning');
}

function capitalize(word) {
  return word.charAt(0).toUpperCase() + word.slice(1);
}

function attachProductClickEvents() {
  document.querySelectorAll('.product-card').forEach(card => {
    card.addEventListener('click', function () {
      const img = this.querySelector('img')?.src || '';
      const title = this.querySelector('.card-title')?.innerText || 'No Title';
      const priceText = this.querySelector('.current-price')?.innerText || '₹0';
      const basePrice = parseInt(priceText.replace(/[₹,]/g, ''));

      document.getElementById('overlayMainImage').src = img;
      document.getElementById('overlayTitle').innerText = title;
      document.getElementById('overlayPrice').innerText = `Price: ₹${basePrice.toLocaleString()}`;
      document.getElementById('productOverlay').setAttribute('data-baseprice', basePrice);
      document.getElementById('productOverlay').setAttribute('data-title', title);
      document.getElementById('productOverlay').setAttribute('data-img', img);

      const thumbnails = [
        img,
        'https://via.placeholder.com/300x200?text=Side+View',
        'https://via.placeholder.com/300x200?text=Back+View'
      ];
      const thumbContainer = document.getElementById('thumbnailContainer');
      thumbContainer.innerHTML = '';
      thumbnails.forEach((src, index) => {
        const thumb = document.createElement('img');
        thumb.src = src;
        if (index === 0) thumb.classList.add('active');
        thumb.addEventListener('click', () => {
          document.getElementById('overlayMainImage').src = src;
          thumbContainer.querySelectorAll('img').forEach(i => i.classList.remove('active'));
          thumb.classList.add('active');
        });
        thumbContainer.appendChild(thumb);
      });

      document.getElementById('brandOverlay')?.classList.add('d-none');
      document.getElementById('productOverlay').classList.remove('d-none');
      document.body.classList.add('no-scroll');
    });
  });
}

function shuffleAndDisplay(templateId, containerId) {
  const template = document.getElementById(templateId);
  const container = document.getElementById(containerId);
  if (!template || !container) return;

  const allCards = Array.from(template.content.cloneNode(true).children);
  const shuffled = allCards.sort(() => 0.5 - Math.random());
  const selected = shuffled.slice(0, 5);

  container.innerHTML = '';
  selected.forEach(card => container.appendChild(card));
}

function showBrandProducts(brandName, categoryType) {
  document.querySelectorAll('section, .carousel-wrapper, .buying-section').forEach(el => el.style.display = 'none');
  document.getElementById('brandTitle').innerText = `Showing "${capitalize(brandName)}" in ${capitalize(categoryType)}`;

  const container = document.getElementById('brandProductsContainer');
  container.innerHTML = '';

  const templates = {
    phone: 'phoneProducts',
    laptop: 'laptopProducts',
    tablet: 'tabletProducts',
    watch: 'watchProducts'
  };

  const templateId = templates[categoryType];
  const template = document.getElementById(templateId);
  if (!template) return;

  const allCards = Array.from(template.content.cloneNode(true).children);
  const filteredCards = allCards.filter(card =>
    card.dataset.brand?.toLowerCase() === brandName &&
    card.dataset.category?.toLowerCase() === categoryType
  );

  filteredCards.forEach(card => {
    card.classList.add('col-md-4', 'col-6');
    container.appendChild(card);
  });

  attachProductClickEvents();
  document.getElementById('brandOverlay').classList.remove('d-none');
  document.body.classList.add('no-scroll');
  window.scrollTo({ top: 0, behavior: 'instant' });
}

function showToast(message, type = 'success') {
  const toastEl = document.getElementById('cartToast');
  if (toastEl) {
    toastEl.querySelector('.toast-body').textContent = message;
    toastEl.className = `toast align-items-center text-white bg-${type} border-0`;
    const toast = new bootstrap.Toast(toastEl);
    toast.show();
  }
}

function addToCart(title, price, img) {
  const existingIndex = cartItems.findIndex(item => item.title === title);
  if (existingIndex >= 0) {
    cartItems[existingIndex].qty = (cartItems[existingIndex].qty || 1) + 1;
  } else {
    cartItems.push({ title, price, img, qty: 1 });
  }
  saveCart();
  renderCartItems();
  const cartSidebar = document.getElementById('cartSidebar');
  if (cartSidebar.classList.contains('d-none')) {
    cartSidebar.classList.remove('d-none');
  }
  showToast('Item added to cart.');
}

function openOverlay(section) {
  const overlay = document.getElementById(`${section}-overlay`);
  const overlayProducts = document.getElementById(`${section}-overlay-products`);
  const templateId = `${section}Products`;
  const template = document.getElementById(templateId);

  if (!template || !overlay || !overlayProducts) return;

  overlayProducts.innerHTML = '';
  const allProducts = Array.from(template.content.cloneNode(true).children);
  allProducts.forEach(prod => {
    prod.classList.add('product');
    overlayProducts.appendChild(prod);
  });

  overlay.style.display = 'block';
  document.body.classList.add('no-scroll');

  attachProductClickEvents();
  setupDynamicFilters(section, allProducts);

  const applyBtn = overlay.querySelector('.apply-filters-btn');
  if (applyBtn) {
    applyBtn.onclick = () => applyOverlayFilters(section);
  }
}

function setupDynamicFilters(section, products) {
  const overlay = document.getElementById(`${section}-overlay`);
  const brandFilter = overlay.querySelector('.filter-brand');
  const categoryFilter = overlay.querySelector('.filter-category');

  const brands = new Set();
  const categories = new Set();

  products.forEach(prod => {
    const brand = prod.dataset.brand?.toLowerCase() || '';
    const category = prod.dataset.category?.toLowerCase() || '';
    if (brand) brands.add(brand);
    if (category) categories.add(category);
  });

  if (brandFilter) {
    brandFilter.innerHTML = '';
    brands.forEach(brand => {
      brandFilter.innerHTML += `<label><input type="checkbox" data-filter-type="brand" value="${brand}" checked> ${capitalize(brand)}</label><br>`;
    });
  }

  if (categoryFilter) {
    categoryFilter.innerHTML = '';
    categories.forEach(cat => {
      categoryFilter.innerHTML += `<label><input type="checkbox" data-filter-type="category" value="${cat}" checked> ${capitalize(cat)}</label><br>`;
    });
  }

  overlay.querySelectorAll('input[data-filter-type]').forEach(input => {
    input.addEventListener('change', () => applyOverlayFilters(section));
  });

  const priceMinInput = overlay.querySelector(`#priceMinInput-${section}`);
  const priceMaxInput = overlay.querySelector(`#priceMaxInput-${section}`);

  if (priceMinInput && priceMaxInput) {
    const syncAndFilter = () => applyOverlayFilters(section);
    priceMinInput.addEventListener('change', syncAndFilter);
    priceMaxInput.addEventListener('change', syncAndFilter);
  }
  enforceDefaultFilters(section);
  applyOverlayFilters(section);
}
document.addEventListener('DOMContentLoaded', () => {
  ['phone', 'laptop', 'tablet', 'watch'].forEach(section => {
    setTimeout(() => enforceDefaultFilters(section), 1000);
  });
});

function enforceDefaultFilters(section) {
  const overlay = document.getElementById(`${section}-overlay`);
  if (!overlay) return;

  // Force check and disable Product Type & Availability
  const essentialFilters = ['product-type', 'availability'];

  essentialFilters.forEach(id => {
    const checkbox = overlay.querySelector(`input[id="${id}"]`);
    if (checkbox) {
      checkbox.checked = true;
      checkbox.disabled = true;
    }
  });
}

document.addEventListener('DOMContentLoaded', () => {
  // Apply to overlays as needed
  ['phone', 'laptop', 'tablet', 'watch'].forEach(section => {
    const overlay = document.getElementById(`${section}-overlay`);
    if (overlay) {
      // If dynamically rendered, delay slightly
      setTimeout(() => enforceDefaultFilters(section), 500);
    }
  });
});


function applyOverlayFilters(section) {
  const overlay = document.getElementById(`${section}-overlay`);
  const allProducts = overlay.querySelectorAll('.product');

  const selectedBrands = Array.from(overlay.querySelectorAll('input[data-filter-type="brand"]:checked')).map(cb => cb.value);
  const selectedCategories = Array.from(overlay.querySelectorAll('input[data-filter-type="category"]:checked')).map(cb => cb.value);

  const priceMin = parseInt(document.getElementById(`priceMinInput-${section}`)?.value || '0');
  const priceMax = parseInt(document.getElementById(`priceMaxInput-${section}`)?.value || '100000');

  allProducts.forEach(prod => {
    const priceText = prod.querySelector('.current-price')?.innerText.replace(/[₹,]/g, '') || '0';
    const price = parseInt(priceText);
    const brand = prod.dataset.brand?.toLowerCase();
    const category = prod.dataset.category?.toLowerCase();
    const matchesBrand = selectedBrands.includes(brand);
    const matchesCategory = selectedCategories.includes(category);
    const inPriceRange = price >= priceMin && price <= priceMax;

    prod.style.display = (matchesBrand && matchesCategory && inPriceRange) ? 'flex' : 'none';
  });
}

function closeOverlay(section) {
  const overlay = document.getElementById(`${section}-overlay`);
  if (overlay) overlay.style.display = 'none';
  document.body.classList.remove('no-scroll');
}

function restoreHomepage() {
  document.getElementById('brandOverlay')?.classList.add('d-none');
  document.getElementById('productOverlay')?.classList.add('d-none');
  document.body.classList.remove('no-scroll');
  document.querySelectorAll('section, .carousel-wrapper, .buying-section').forEach(el => el.style.display = '');
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

document.addEventListener('DOMContentLoaded', function () {
  const overlay = document.getElementById('productOverlay');

  overlay?.querySelector('.btn-success')?.addEventListener('click', function () {
    const title = overlay.getAttribute('data-title');
    alert(`Proceeding to Buy: ${title}`);
  });

  overlay?.querySelector('.btn-outline-primary')?.addEventListener('click', function () {
    const title = overlay.getAttribute('data-title');
    const priceText = document.getElementById('overlayPrice').innerText;
    const img = overlay.getAttribute('data-img');
    addToCart(title, priceText, img);
  });

  overlay.querySelectorAll('.condition-option').forEach(btn => {
    btn.addEventListener('click', () => {
      overlay.querySelectorAll('.condition-option').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      const basePrice = parseInt(overlay.getAttribute('data-baseprice') || '0');
      let price = basePrice;
      switch (btn.dataset.condition) {
        case 'like-new': price = basePrice; break;
        case 'good': price = Math.round(basePrice * 0.95); break;
        case 'fair': price = Math.round(basePrice * 0.90); break;
      }
      document.getElementById('overlayPrice').innerText = `Price: ₹${price.toLocaleString()}`;
    });
  });

  document.querySelectorAll('.dropdown-menu p:not(.dropdown-heading)').forEach(brand => {
    brand.style.cursor = 'pointer';
    brand.addEventListener('click', () => {
      const brandName = brand.innerText.trim().toLowerCase();
      const categoryType = brand.dataset.category || '';
      showBrandProducts(brandName, categoryType);
    });
  });

  document.getElementById('searchInput')?.addEventListener('input', e => {
    const term = e.target.value.toLowerCase();
    document.querySelectorAll('.product-card').forEach(card => {
      const title = card.querySelector('.card-title')?.innerText.toLowerCase() || '';
      card.style.display = title.includes(term) ? '' : 'none';
    });
  });

  document.getElementById('cartToggleBtn')?.addEventListener('click', toggleCartSidebar);
  document.getElementById('clearCartBtn')?.addEventListener('click', clearCart);

  shuffleAndDisplay('phoneProducts', 'phoneContainer');
  shuffleAndDisplay('laptopProducts', 'laptopContainer');
  shuffleAndDisplay('tabletProducts', 'tabletContainer');
  shuffleAndDisplay('watchProducts', 'watchContainer');

  attachProductClickEvents();
  renderCartItems();
});

function clearOverlayFilters(section) {
  const overlay = document.getElementById(`${section}-overlay`);

  // Uncheck brand and category filters
  overlay.querySelectorAll('input[data-filter-type="brand"], input[data-filter-type="category"]').forEach(cb => {
    cb.checked = false;
  });

  // Reset price inputs
  const minInput = overlay.querySelector(`#priceMinInput-${section}`);
  const maxInput = overlay.querySelector(`#priceMaxInput-${section}`);

  if (minInput && maxInput) {
    minInput.value = 0;
    maxInput.value = 100000;
  }

  applyOverlayFilters(section);
}
